/**
 * Función que informa al usuario de la plataforma sobre la que el navegador está ejecutandose
 * haciendo uso del objeto navigator.
 */
function consultarPlataforma(){

    // Variable que recogerá la plataforma sobre la que se ejecuta el navegador
    var plataforma = navigator.platform;

    document.getElementById("plataforma").setAttribute("value", plataforma); //mostramos la plataforma

    document.getElementById("info").removeAttribute("hidden"); //preguntamos al usuario si quiera más información

}

/**
 * Función que ofrece más información al usuario en el caso de que quiera más información sobre su navegador.
 */
function masInfo(){

    document.getElementById("cajon-mas-info").removeAttribute("hidden"); //mostramos la información extra

    // Formamos la cadena masInformacion con algunos de los métodos del objeto navigator para ofrecerlo como información
    var masInformacion = "Nombre del navegador: " + navigator.appName + "\n";

    masInformacion += "Codename del navegador: " + navigator.appCodeName + "\n";

    masInformacion += "Versión del navegador: " + navigator.appVersion + "\n";

    masInformacion += "¿Están las cookies habilitadas en tu navegador?: " + navigator.cookieEnabled + "\n";

    masInformacion += "Idioma del navegador: " + navigator.language + "\n";

    masInformacion += "¿Se encuentra el navegador conectado a internet: " + navigator.onLine + "\n";

    // mostramos en la página la información extra
    document.getElementById("mas-info").innerHTML = masInformacion;

}

/**
 * Función que elimina y oculta la opción de más información en el caso de que el usuario no quiera más información
 */
function noInfo(){
    document.getElementById("mas-info").innerHTML = "";
    document.getElementById("info").setAttribute("hidden", true); // volvemos a ocultar la pregunta sobre más información 
    document.getElementById("cajon-mas-info").setAttribute("hidden", true); // volvemos a ocultar el cajón donde mostramos la información
}