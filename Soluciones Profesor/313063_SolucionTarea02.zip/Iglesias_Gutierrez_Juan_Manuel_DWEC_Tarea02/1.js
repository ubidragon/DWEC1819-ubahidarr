/* 
    Signos del horoscopo Maya

    10/01 - 06/02 = Mono
    url = http://www.horoscopomaya2019.com/horoscopo-maya-mono/

    07/02 - 06/03 = Halcón
    url = http://www.horoscopomaya2019.com/horoscopo-maya-halcon/

    07/03 - 03/04 = Jaguar
    url = http://www.horoscopomaya2019.com/horoscopo-maya-jaguar/

    04/04 - 01/05 = Zorro
    url = http://www.horoscopomaya2019.com/horoscopo-maya-zorro/

    02/05 - 29/05 = Serpiente
    url = http://www.horoscopomaya2019.com/horoscopo-maya-serpiente/

    30/05 - 26/06 = Ardilla
    url = http://www.horoscopomaya2019.com/horoscopo-maya-ardilla/

    27/06 - 25/07 = Tortuga
    url = http://www.horoscopomaya2019.com/horoscopo-maya-tortuga/
    
    26/07 - 22/08 = Murciélago
    url = http://www.horoscopomaya2019.com/horoscopo-maya-murcielago/

    23/08 - 19/09 = Escorpión
    url = http://www.horoscopomaya2019.com/horoscopo-maya-escorpion/

    20/09 - 17/10 = Venado
    url = http://www.horoscopomaya2019.com/horoscopo-maya-venado/

    18/10 - 14/11 = Lechuza
    url = http://www.horoscopomaya2019.com/horoscopo-maya-lechuza/

    15/11 - 12/12 = Pavo real
    url = http://www.horoscopomaya2019.com/horoscopo-maya-pavo-real/

    13/12 - 09/01 = Lagarto
    url = http://www.horoscopomaya2019.com/horoscopo-maya-lagarto/
*/ 


/**
 * Función que devuelve en un iframe la página del horoscopo maya correspondiente a la fecha de nacimiento que el usuario introduce
 * en el formulario.
 */
function obtenerSignoHoroscopo(){

    // Variable que comprobará si se cumplen las reglas para una fecha válida
    var esFechaValida = false;
    
    // Variable asignada al cajón div donde irá el iframe de la página del horoscopo maya a mostrar
    var iFrame = document.getElementById("el-iframe");

    // Recogemos la fecha de nacimiento introducida por el usuario en el formulario
    //getElementById()=Para acceder a un elemento identificado por el id escrito entre paréntesis.
    var laFechaNacimiento = document.getElementById("texto-usuario").value; 
    //console.debug(laFechaNacimiento);

    // Usando el método substring obtenemos la porción que pertenece al día de la cadena laFechaNacimiento
    var dia = laFechaNacimiento.substring(0, 2);
    //console.debug("Día: " + dia);

    // Usamos la función parseInt() para analizar la cadena dia y obtener el día como número entero
    var elDiaNumerico = parseInt(dia);
    //console.debug("Día como entero: " + elDiaNumerico);

    // Usando el método substring obtenemos la porción que pertenece al mes de la cadena laFechaNacimiento
    var mes = laFechaNacimiento.substring(3, 5);
    //console.debug("mes: " + mes);

    // Usamos la función parseInt() para analizar la cadena mes y obtener el mes como número entero
    var elMesNumerico = parseInt(mes);
    //console.debug("Mes como entero: " + elMesNumerico);

    // Usando el método substring obtenemos la porción que pertenece al año de la cadena laFechaNacimiento
    var anio = laFechaNacimiento.substring(6, 10);
    //console.debug("Año: " + anio);

    // Usamos la función parseInt() para analizar la cadena año y obtener el año como número entero
    var elAnioNumerico = parseInt(anio);
    //console.debug("Año como entero: " + elAnioNumerico);

    // Usando el método substring obtenemos la porción que pertenece al año de la cadena laFechaNacimiento
    var separador1 = laFechaNacimiento.substring(2, 3);
    var separador2 = laFechaNacimiento.substring(5, 6);
    //console.debug("Separador entre el día y el mes: " +  separador1);
    //console.debug("Separador entre el mes y el año: " +  separador2);

    /*
    Antes de inicializar el objeto Date con los parámetros de año, mes y día tenemos que comprobar lo siguiente:
        
        1. Que no se pasa el día, mes o año como un carácter no numérico
        2. Que se respeta el formato dd/mm/aaaa
        3. Que el día está dentro del rango de días del mes que le corresponde (ejemplo: el 30 de febrero estaría mal)
    */

    // 1. Que no se pasa el día, mes o año como un carácter no numérico
    if(isNaN(elDiaNumerico) || isNaN(elMesNumerico) || isNaN(elAnioNumerico)){

        document.getElementById("msg").innerHTML = "Por favor, introduce la fecha con carácteres numéricos.";
        document.getElementById("msg").style.backgroundColor = "#ffebe6";

        // Ocultamos el iframe
        document.getElementById("cajon-iframe").setAttribute("hidden", true);

    // 2. Que se respeta el formato dd/mm/aaaa
    }else if(separador1 != "/" || separador2 != "/"){

        document.getElementById("msg").innerHTML = "Por favor, introduce la fecha con el formato correcto (dd/mm/aaaa).";
        document.getElementById("msg").style.backgroundColor = "#ffebe6";

        // Ocultamos el iframe
        document.getElementById("cajon-iframe").setAttribute("hidden", true);
        
    // 3. Que el día está dentro del rango de días del mes que le corresponde (ejemplo: el 30 de febrero estaría mal)
    }else{

        // Este bloque comprueba si el día está en el rango de días correcto dentro del mes que le corresponde
        switch (elMesNumerico) {
            // Enero, Marzo, Mayo, Julio, Agosto, Octubre, Diciembre tienen 31 días
            case 1:
            case 3:
            case 5:
            case 7:
            case 8:
            case 10:
            case 12:
            //console.debug("Mes de 31 días");
            if(elDiaNumerico >=1 && elDiaNumerico <= 31){

                esFechaValida = true; //fecha válida

            }
                break;

            // Abril, Junio, Septiembre, Noviembre tiene 30 días
            case 4:
            case 6:
            case 9:
            case 11:
            //console.debug("Mes de 30 días");
            if(elDiaNumerico >=1 && elDiaNumerico <= 30){

                esFechaValida = true; //fecha válida

            }
                break;

            // Febrero tiene 28 días o 29 si es bisiesto
            case 2:
            /*
            Año bisiesto es el divisible entre 4, salvo que sea año secular -último de cada siglo, terminado en «00»-, 
            en cuyo caso también ha de ser divisible entre 400. 
            (Fuente: wikipedia)
            */
                //Si el año es bisiesto
                if (((elAnioNumerico % 4 == 0) && 
                     !(elAnioNumerico % 100 == 0))
                     || (elAnioNumerico % 400 == 0)){

                     console.debug("febrero de 29 días");
                     if(elDiaNumerico >=1 && elDiaNumerico <= 29){

                        esFechaValida = true; //fecha válida
        
                    }
                // Si el año no es bisiesto
                }else{
                    console.debug("Febrero de 28 días");
                    if(elDiaNumerico >=1 && elDiaNumerico <= 28){

                        esFechaValida = true; //fecha válida
        
                    }
                }
                break;

            default:
            document.getElementById("msg").innerHTML = "Por favor, introduce la fecha con el formato correcto.";
            document.getElementById("msg").style.backgroundColor = "#ffebe6";
    
            // Ocultamos el iframe
            document.getElementById("cajon-iframe").setAttribute("hidden", true);
                break;
        }//fin del switch

    }//fin del else

    // Si la fecha es válida ya podemos crear el objeto Date
    if(esFechaValida){ 

        console.debug("La fecha es válida");

        /* 
        Inicializamos un objeto Date con 4 números pasados por parámetro correspondientes a:
        new Date(año, mes, dia);
    
        JavaScript cuenta los meses desde 0 a 11. Por lo tanto enero sería el mes 0 y diciembre el mes 11.
        Tendremos que restarle 1 al mes para que javascript interprete correctamente el mes al crear el objeto Date.


        */
        var fecha = new Date(elAnioNumerico, elMesNumerico-1, elDiaNumerico);
        //console.debug("La fecha: " + fecha);
        //console.debug("Fecha en formato local: " + fecha.toLocaleString()); //fecha en formato local

        /* 
        Obtenemos el mes usando el métedo getMonth()
        Sumamos 1 al valor devuelto por el método getMonth() porque nos devuelve un numero entre el 0 y el 11, ya que empieza a contar desde el 0.
        */
        //getMonth() 	Get the month as a number (0-11)
        var elMes = fecha.getMonth()+1;
        //console.debug("Mes: " + elMes);

        /*
        Usamos el método getDate() que nos devolvería el día
        */
        //getDate() 	Get the day as a number (1-31)
        var elDia = fecha.getDate();
        //console.debug("Día: " + elDia);

        /*
        Usaremos la declaración switch para cargar la página del horoscopo en función del mes y día de la fecha de nacimiento del usuario.
        Hacemos una primera selección por meses para luego dentro de cada mes hacer una selección del signo dependiendo
        del rango de días en el que nos encontremos.
        Por tanto pasamos como parámetro el mes y ejecutamos un bloque de código dependiendo del mes.
        */
        switch(elMes){
            // Si el mes es enero
            case 1:

                // y el día está comprendido entre el 1 y el 9 ambos inclusive, cargaremos esta url:
                if(elDia >= 1 && elDia <= 9){ 
                    //console.debug("Lagargo");
                    // Pasamos al atributo src la url que corresponde
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-lagarto/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");  
                
                // Si el día está fuera del rango (1-9) del mes de enero, cargaremos esta url:
                }else{
                    //console.debug("Mono");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-mono/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 2: //Febrero

                if(elDia >= 1 && elDia <= 6){
                    //console.debug("Mono");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-mono/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Halcón");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-halcon/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 3: //Marzo

                if(elDia >= 1 && elDia <= 6){
                    //console.debug("Halcon");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-halcon/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Jaguar");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-jaguar/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 4: //Abril

                if(elDia >= 1 && elDia <= 3){
                    //console.debug("Jaguar");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-jaguar/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Zorro");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-zorro/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 5: //Mayo

                if(elDia = 1){
                    //console.debug("Zorro");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-zorro/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
                    
                if(elDia >= 2 && elDia <= 29){
                    //console.debug("Serpiente");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-serpiente/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                
                }else{
                    //console.debug("Ardilla");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-ardilla/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 6: //Junio

                if(elDia >= 1 && elDia <= 26){
                    //console.debug("Ardilla");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-ardilla/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Tortuga");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-tortuga/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 7: //Julio

                if(elDia >= 1 && elDia <= 25){
                    //console.debug("Tortuga");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-tortuga/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Murciélago");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-murcielago/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 8: //Agosto

                if(elDia >= 1 && elDia <= 22){
                    //console.debug("Murciélago");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-murcielago/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Escorpión");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-escorpion/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 9: //Septiembre

                if(elDia >= 1 && elDia <= 19){
                    //console.debug("Escorpión");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-escorpion/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Venado");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-venado/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 10: //Octubre

                if(elDia >= 1 && elDia <= 17){
                    //console.debug("Venado");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-venado/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Lechuza");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-lechuza/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 11: //Noviembre

                if(elDia >= 1 && elDia <= 14){
                    //console.debug("Lechuza");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-lechuza/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Pavo Real");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-pavo-real/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;

            case 12: //Diciembre

                if(elDia >= 1 && elDia <= 12){
                    //console.debug("Pavo Real");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-pavo-real/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }else{
                    //console.debug("Lagargo");
                    iFrame.setAttribute("src", "http://www.horoscopomaya2019.com/horoscopo-maya-lagarto/");
                    document.getElementById("cajon-iframe").removeAttribute("hidden");
                }
            
            break;
            
            /*
            Para cualquier valor de la variable elMes que no sea un número del 1 al 12, ejecturemos este trozo de código indicando
            al usuario que introduzca una fecha con formato correcto.
            */
            default:
            document.getElementById("msg").innerHTML = "Por favor, introduce la fecha con el formato correcto (dd/mm/aaaa).";
            document.getElementById("msg").style.backgroundColor = "#ffebe6";

            // Ocultamos el iframe
            document.getElementById("cajon-iframe").setAttribute("hidden", true);

            break;
            
        }//fin de la sentencia switch



    // Si la fecha no es válida, informamos al usuario
    }else{
        document.getElementById("msg").innerHTML = "Por favor, introduce la fecha con el formato correcto.";
        document.getElementById("msg").style.backgroundColor = "#ffebe6";
    
        // Ocultamos el iframe
        document.getElementById("cajon-iframe").setAttribute("hidden", true);

    }
}

/**
 * Función que elimina el mensaje de error al usuario
 */
function limpiarMensaje(){
    document.getElementById("msg").innerHTML = ""; //limpiamos el mensaje
    document.getElementById("msg").style.backgroundColor = "#ebeeee"; //cambiamos el color del div para ocultarlo
}

