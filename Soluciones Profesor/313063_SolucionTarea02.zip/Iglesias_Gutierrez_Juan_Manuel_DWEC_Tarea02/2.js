/**
 * Función que borra los carácteres repetidos de una cadena considerando los carácteres en mayúsculas y minúsculas como carácteres distintos.
 */

function borrarRepetidas(){

    // Obtenemos la cadena de texto que el usuario a introducido en el formulario
    var cadenaUsuario = document.getElementById("texto-usuario").value;
    //console.debug(cadenaUsuario);

    // Cadena que recogerá el resultado después de usar la función
    var cadenaResultante = "";
    

    // Devuelve en número de carácteres en una cadena
    //console.debug(cadenaUsuario.length);

    // Devuelve el carácter en la posición del indice que se pase como parámetro a charAt()
    //console.debug(cadenaUsuario.charAt(0));

    // Si el usuario introduce algún texto seguimos con el script
    if(cadenaUsuario != ""){
        //Este bucle for recorre toda la cadena leyendo uno a uno los carácteres que la componen
        //console.debug ("Este bucle for se repetirá " + cadenaUsuario.length + " veces.");
        for(var i = 0; i < cadenaUsuario.length; i++){

                //console.debug("Comparamos el carácter " + cadenaUsuario.charAt(i+1) + " con el carácter " + cadenaUsuario.charAt(i));
            
                /*
                Comparamos el carácter en la posición del iterador con el carácter en la posición del iterador una posición adelantada.
                De tal modo que se compara un carácter con el anterior recorriendo toda la cadena.
                Si el carácter que precede al carácter actual [cadenaUsuario.charAt(i)], es decir, [cadenaUsuario.charAt(i+1)] es distinto, entonces
                añadiremos ese carácter [cadenaUsuario.charAt(i)] a la cadena cadenaResultante que irá formando una cadena con todos los carácteres no iguales.
                */
                if(cadenaUsuario.charAt(i+1) != cadenaUsuario.charAt(i)) {
                    
                    // es lo mismo que cadenaResultante = cadenaResultante + cadenaUsuario.charAt(i)
                    cadenaResultante += cadenaUsuario.charAt(i);
                
                }
                
                /* else{ // En caso contrario el carácter estará repetido

                    console.debug("El carácter (" + cadenaUsuario.charAt(i+1) + ") que se encuentra en la posición [" + (i+1) + "] está repetido.");
                } */

        
        }// fin de la sentencia for

        //console.debug("Cadena resultante: " + cadenaResultante);
        // Mostramos el resultado de la función
        document.getElementById("resultado").innerHTML = "<strong>Resultado: </strong>" + cadenaResultante;
        document.getElementById("resultado").style.backgroundColor = "#c8f1f1";
        document.getElementById("resultado").removeAttribute("hidden");

    // Si el usuario no introduce un texto, se le informa que lo haga
    }else{
        document.getElementById("msg").innerHTML = "Por favor, introduce un texto.";
        document.getElementById("msg").style.backgroundColor = "#ffebe6";
        document.getElementById("resultado").setAttribute("hidden", true);
    }

}

/**
 * Función que elimina el mensaje de error al usuario
 */
function limpiarMensaje(){
    document.getElementById("msg").innerHTML = "";
    document.getElementById("msg").style.backgroundColor = "#ebeeee";
}