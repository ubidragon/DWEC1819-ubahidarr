/**
 * Función que calcula el área y el perímetro de un hexágono regular a partir de la longitud del lado que el usuario introduce en el formulario.
 */
function calcular(){

    // El lado introducido por el usuario
    var lado = document.getElementById("lado").value;

    // Comprobamos si el dato introducido en el formulario es o no numérico.
    // Si no es numérico informamos al usuario para que introduzca un número.
    if(isNaN(lado)){

        document.getElementById("msg").innerHTML = "Para realizar el cáculo, el lado tiene que ser numérico.";
        document.getElementById("msg").style.backgroundColor = "#ffebe6";
        document.getElementById("resultado").setAttribute("hidden", true);//ocultamos el resultado ya que no es válido el dato introducido

    // en el caso de que no introduzca ningún dato se informará al usuario que el campo no puede estar vacío 
    }else if(lado == ""){

        document.getElementById("msg").innerHTML = "Para realizar el cáculo, el campo lado no puede estar vacío.";
        document.getElementById("msg").style.backgroundColor = "#ffebe6";
        //se ocultan todos los campos ya que el dato no es válido
        document.getElementById("apotema").setAttribute("hidden", true);
        document.getElementById("perimetro").setAttribute("hidden", true);
        document.getElementById("area").setAttribute("hidden", true);

    }else{ //si todo está correcto comenzamos a realizar los cálculos 

        var apotema = Math.sqrt((lado**2)-((lado/2)**2)); //calculamos la apotema

        var perimetro = 6 * lado; //calculamos el perímetro

        var area = (perimetro * apotema)/2; //calculamos el área

        // Mostramos al usuario el resultado de los cálculos realizados
        document.getElementById("apotema").innerHTML = "<strong>El valor de la apotema es: </strong>" + parseFloat(apotema).toFixed(2) + " cm";
        document.getElementById("apotema").removeAttribute("hidden");

        document.getElementById("perimetro").innerHTML = "<strong>El valor del perímetro es: </strong>" + parseFloat(perimetro).toFixed(2) + " cm";
        document.getElementById("perimetro").removeAttribute("hidden");

        document.getElementById("area").innerHTML = "<strong>El valor del área es: </strong>" + parseFloat(area).toFixed(2) + " cm&sup2;";
        document.getElementById("area").removeAttribute("hidden");

    } //fin bloque if{}else if{}else{}
    

    
}//fin de la función calcular()

/**
 * Función que elimina el mensaje de error al usuario
 */
function limpiarMensaje(){
    document.getElementById("msg").innerHTML = "";
    document.getElementById("msg").style.backgroundColor = "#ebeeee";
}