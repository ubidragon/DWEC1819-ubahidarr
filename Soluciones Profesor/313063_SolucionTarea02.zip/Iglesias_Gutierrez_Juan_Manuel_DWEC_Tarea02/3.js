/**
 * Función que detectará los espacios y puntos en una cadena y los sustituirá por puntos (.) y comas (,) respectivamente.
 */
function cambiar(){

    /*Obtenemos la cadena de texto que el usuario a introducido en el formulario*/
    var cadenaUsuario = document.getElementById("texto-usuario").value;

    //console.debug(cadenaUsuario);

    // El carácter de la cadena que analizaremos en el switch
    var caracter;

    // Cadena resultante después de terminar el script
    var cadenaResultante = "";

    // Si el usuario introduce algún texto seguimos con el script
    if(cadenaUsuario != ""){

        /*
        Recorremos la cadena 'cadenaUsuario' carácter a carácter para según el caso de la sentencia switch cree una nueva
        cadena en la que se sustituye el punto  por una coma y el espacio por un punto. Si el carácter no es ninguno de estos dos 
        casos, se ejecutará el caso por defecto (default) que asigna el carácter tal cual (sin cambios).
        */
        for(var i = 0; i < cadenaUsuario.length; i++){
            
            // asignamos el carácter en la posición i de la cadena a la variable caracter
            caracter = cadenaUsuario.charAt(i);

            // La sentencia switch ejecutará un bloque de código en función de carácter pasado por parámetro.
            switch(caracter){

                
                case caracter = ".": // Si el carácter es un punto:
                //console.debug("Punto encontrado. Cambiamos el (.) por una (,)");

                /*
                Añadiremos a la nueva cadena 'cadenaResultante' el carácter (,).
                Hay que recordar que la posición se empieza a contar desde 0
                */
                cadenaResultante += ",";
                break;

            
                case caracter = " ": // Si el carácter es un espacio:
                //console.debug("Espacio encontrado. Cambiamos el espacio por un (.)");

                /*
                Añadiremos a la nueva cadena 'cadenaResultante' el carácter (.).
                */
                cadenaResultante += ".";
                break;

                default: // en el caso de que el carácter no sea ni un punto ni un punto, asignamos el carácter sin cambios
                cadenaResultante += cadenaUsuario.charAt(i);
                //console.debug("Añadiendo el carácter (" + cadenaUsuario.charAt(i) + ") a la cadena: " + cadenaResultante);

            }//Fin bucle switch

        }//Fin bucle for

        // Mostramos el resultado de la función
        document.getElementById("resultado").innerHTML = "<strong>Resultado: </strong>" + cadenaResultante;
        document.getElementById("resultado").style.backgroundColor = "#c8f1f1";
        document.getElementById("resultado").removeAttribute("hidden");

    // Si el usuario no escribe un texto le indicamos que escriba un texto
    }else{
        document.getElementById("msg").innerHTML = "Por favor, introduce un texto.";
        document.getElementById("msg").style.backgroundColor = "#ffebe6";
        document.getElementById("resultado").setAttribute("hidden", true);
    }

}

/**
 * Función que elimina el mensaje de error al usuario
 */
function limpiarMensaje(){
    document.getElementById("msg").innerHTML = "";
    document.getElementById("msg").style.backgroundColor = "#ebeeee";
}