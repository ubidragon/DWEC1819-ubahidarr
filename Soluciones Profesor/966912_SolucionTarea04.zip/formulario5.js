// Primera instrucción que se ejecutará cuando el documento esté cargado.
// Se hará una llamada a la función iniciar()
// De esta manera nos aseguramos que las asignaciones de eventos no fallarán ya que
// todos los objetos están disponibles.
window.onload = iniciar;

// Variable para almacenar el mensaje a mostrar en el DIV resultado
var mensaje = "";
// Se añaden los eventos de click para 'enviar'
// Registramos el contador de competiciones inscritas a traves de localStorage

    // Borramos los datos de localStorage si ya existen previamente
localStorage.setItem("competiciones", "0");

//----------------------------------------------------------//

// Asigna el evento validar en el boton enviar.
function iniciar() {

    // Al hacer click en el botón de enviar llama a la la función validar que se encargará
    // de validar el formulario, lo programamos en la fase de burbujeo (false).

    document.getElementById("enviar").addEventListener('click', validar, false);

}

//----------------------------------------------------------//

// Función que valida que se cumpla la función validarcampos() y se pulse en aceptar sobre el mensaje de envio del formulario
// Si se cumple los requisitos devuelve true, incluye en el div resultado el mensaje almacenado.
// Incluye en el div competiciones el número de inscritos 
// Incrementa el valor de localStorage ("competiciones") En una unidad cada vez que lo valide.
// Se cancela el evento para que no se envíe el formulario tanto si validar devuelve true como si devuelve false.

function validar(eventopordefecto) {
    //	Introducimos el valor de localStorage mas 1 en la variable valor
    var valor = parseInt(localStorage.getItem("competiciones")) + 1;
    // limpiamos el contenido del mensaje a mostrar para no acumular mensajes anteriores.
    mensaje = "";

    
    // Si valida cada una de las funciones que llamamos devuelve true
    if (validarcampos() && confirm("¿Deseas enviar el formulario?")) {
        // mostramos mensaje con datos introducidos
        document.getElementById("resultado").innerHTML = mensaje;
        // Asignamos a localStorage el valor de competiciones que previamente hemos incrementado.
        localStorage.setItem ("competiciones", valor);
        // Mostramos el valor de localStorage en el DIV competiciones al haber sido exitosa la inscripción
        document.getElementById("competiciones").innerHTML = "Se han inscrito " + localStorage.getItem("competiciones") + " competiciones .<br>";
        // Cancelamos el evento de envío por defecto asignado al boton enviar.
        eventopordefecto.preventDefault();
        return true; // Salimos de la función devolviendo true.

    // Sino devuelve false, mostramos el resultado del mensaje y deshacemos el incremento de valor de la cookie.    
    } else {
        // mostramos mensaje con datos introducidos
        document.getElementById("resultado").innerHTML = mensaje;
        // Dejamos tal cual el valor de localStorage al no aumentar el número de competiciones

        // Cancelamos el evento de envío por defecto asignado al boton enviar.
        eventopordefecto.preventDefault();
        return false; // Salimos de la función devolviendo false.
    }
}

//----------------------------------------------------------//

// Función que valida que todos los campos requeridos esten rellenos(tan sólo nombre es obligatorio).
// Cambia el mensaje por defecto de cada campo si hay errores.
// Devuelve false si no se cumple algun requisito (Si se cumple algun bucle IF)
// Devuelve true si ha pasado por todos los bucles sin que se cumplan sus requisitos
// Modifica el estilo de cada campo según si es correcto o no
// Añade a la variable mensaje el valor de los campos rellenados si son correctos.
function validarcampos() {
    
   // Asignamos a la variable nombre el objeto nombre 
    var nombre= document.getElementById("nombre");
    // Asignamos a la variable descripcion el objeto descripcion 
    var descripcion= document.getElementById("descripcion");
    // Asignamos a la variable participantes el objeto participantes 
    var participantes= document.getElementById("participantes");
    // Asignamos a la variable arma el objeto arma 
    var arma= document.getElementById("arma");
    
    // Sino se ha escrito nada en nombre cambia el mensaje de error.
     if (document.getElementById("nombre").value == ""){
         nombre.setCustomValidity("Introduzca algún valor en el campo nombre.");
         document.getElementById("nombre").className="error";
         return false;
     }
    
    // Variable que guarda el patron requerido en el campo nombre
    var patronnombre = /^[\w\s\.,;:]{6,40}$/;
    // Si el campo nombre no cumple el patrón devolvemos false y cambiamos el mensaje de error a mostrar.
    if (!patronnombre.test(document.getElementById("nombre").value)){
        nombre.setCustomValidity("Solo caracteres alfanuméricos,signos de puntuación y espacios, entre 6 y 40 caracteres");
        document.getElementById("nombre").className="error";
        return false;
    }
    
    // Variable que guarda el patron requerido en el campo descripción
    var patrondescripcion = /^[\w\s\.,;:]{0,1024}$/;
    // Si el campo descripción no cumple el patrón devolvemos false y cambiamos el mensaje de error a mostrar
    if (!patrondescripcion.test(document.getElementById("descripcion").value)){
        descripcion.setCustomValidity("Solo caracteres alfanuméricos,signos de puntuación y espacios");
        document.getElementById("descripcion").className="error";
        return false;
    }
    
  
    // Si el valor de participantes es inferior a 2 y superior a 100 cambiamos el mensaje de error a mostrar y devolvemos false.
    if (document.getElementById("participantes").value<2 || document.getElementById("participantes").value>100){
        participantes.setCustomValidity("Entre 2 y 100 participantes, no caben mas");
        document.getElementById("participantes").className="error";
        return false;
    }
    
    // Interpretamos que aunque no es obligatiorio, se debe indicar algun arma, aunque no sea del listado propuesto.
    //  Si se permitiese dejar en blanco sin rellenar eliminaríamos este bucle if (de linea 120 a 124)
    if (document.getElementById("arma").value== ""){
        arma.setCustomValidity("Debe seleccionar un arma existente o incluir una nueva");
        document.getElementById("arma").className="error";
        return false;
    }
    
    // Añadimos a la variable mensaje el valor de cada campo y cambiamos el estilo modificando su clase a acierto.
    // Devolvemos true
    mensaje += "El nombre de la competición es: "+nombre.value+ ".<br>Descripción: "+descripcion.value+".<br>Número de participantes: "+
        participantes.value+".<br>Arma a usar: "+arma.value+".";
    document.getElementById("nombre").className="acierto";
    document.getElementById("descripcion").className="acierto";
    document.getElementById("participantes").className="acierto";
    document.getElementById("arma").className="acierto";
    
    return true;
    
   
}



