// Nota: Este script se tendrá que ejecutar desde otro navegador que no sea Chrome,
// de lo contrario no se podrán crear las cookies (al llamarse desde file: por ejecutarse en local, Chrome necesita ser llamado desde http:)

// Primera instrucción que se ejecutará cuando el documento esté cargado.
// Se hará una llamada a la función iniciar()
// De esta manera nos aseguramos que las asignaciones de eventos no fallarán ya que
// todos los objetos están disponibles.
window.onload = iniciar;

// Variable para almacenar el mensaje a mostrar en el DIV resultado
var mensaje = "";
//Variable para almacenar el id del elemento de tipo input text o con id nacionalidad que tiene el foco en el formulario
var elementoconfoco = "";
// Se añaden los eventos de click para 'enviar' y 'limpiar' y un evento de click para el formulario en general
// Borramos la cookie (si está creada) para volver a contar desde 0

//----------------------------------------------------------//

// Borra la cookie si existe y asigna los eventos
function iniciar() {

    // Borramos la cookie si ya existe.
    borrarCookie("inscriptor");
    // Al hacer click en el botón de enviar llama a la la función validar que se encargará
    // de validar el formulario.
    // Al hacer click en el botón limpiar llama a la función limpiarcampo que se encargará
    // de poner en blanco el campo input que tenga el foco
    // Al hacer click en cualquier zona del formulario llama a la función guardar foco 
    //que se encargará de guardar en la variable elementofoco el id del input o select donde se hace el click.
    // Los eventos de click lo programamos en la fase de burbujeo (false).

    document.getElementById("enviar").addEventListener('click', validar, false);
    document.getElementById("limpiar").addEventListener('click', limpiarcampo, false);
    document.getElementById("formulario").addEventListener('click', guardarfoco, false);

}

//----------------------------------------------------------//

// Funcion que valida que ningún campo este sin rellenar y verifica que cumple las funciones que comprueban
// los requisitos correctos solicitados. No usamos required al no poder usar html en esta tarea, lo manejamos
// con funciones que validan si estan los campos vacíos o no.
// Si se cumplen todos los requisitos leemos el valor actual de la cookie (o 0 si no existe) y aumentamos su valor en 1 y devolvemos true
// Añadimos a la variable mensaje la cadena que se ha creado con el recorrido de las funciones pasadas en el IF, tanto si se cumple
// como si no se cumplen los requisitos, dado que en la cadena mensaje hemos ido añadiendo texto según si es correcto o erróneo.
// Se cancela el evento para que no se envíe el formulario tanto si validar devuelve true como si devuelve false.

function validar(eventopordefecto) {
    //	Introducimos el valor de la cookie almacenada en la variable valor mas 1(si tiene datos, ya que de lo contrario almacenamos 1)
    var valor = parseInt(leerCookie("inscriptor")) + 1;
    // limpiamos el contenido del mensaje a mostrar para no acumular mensajes anteriores.
    mensaje = "";

    // Si valida cada una de las funciones que llamamos devuelve true
    if (validarcampostexto(this) && validarnombre() && validarapellidos() && validarcontraseña() && validarnacion() && confirm("¿Deseas enviar el formulario?")) {
        // mostramos mensaje con datos introducidos
        document.getElementById("resultado").innerHTML = mensaje;
        // Creamos la cookie si no está creada. Si ya la tenemos le introducimos el nuevo valor
        crearCookie("inscriptor", valor, 30);
        // Mostramos el valor de la cookie incrementada en 1 desde la última vez
        document.getElementById("inscritos").innerHTML = "Se han inscrito " + valor + " personas .<br>";
        // Cancelamos el evento de envío por defecto asignado al boton enviar.
        eventopordefecto.preventDefault();
        return true; // Salimos de la función devolviendo true.

        // Sino devuelve false, mostramos el resultado del mensaje y deshacemos el incremento de valor de la cookie.    
    } else {
        // mostramos mensaje con datos introducidos
        document.getElementById("resultado").innerHTML = mensaje;
        // Creamos la cookie si no está creada. 
        //Si ya la tenemos le introducimos el nuevo valor menos 1 al no haberse incrito con éxito (el que tenía antes)
        crearCookie("inscriptor", valor - 1, 30);

        // Cancelamos el evento de envío por defecto asignado al boton enviar.
        eventopordefecto.preventDefault();
        return false; // Salimos de la función devolviendo false.
    }
}

//----------------------------------------------------------//

// Función que valida que todos los campos de texto esten rellenos. 
function validarcampostexto(objeto) {
    // A esta función le pasamos un objeto, que en este caso es el botón de enviar.
    // Puesto que validarcampostexto(this) hace referencia al objeto dónde se programó ese evento
    // que fue el botón de enviar.
    var formulario = objeto.form;
    // La propiedad form del botón enviar contiene la referencia del formulario dónde está ese botón.
    // De esta manera podemos recorrer todos los elementos del formulario, buscando los que son de tipo texto.
    // Para validar que contengan valores.

    var error = true; // en un principio es cierto que valida los campos
    for (var i = 0; i < formulario.elements.length; i++) {
        // Eliminamos la clase Error que estuviera asignada a algún campo.
        formulario.elements[i].className = "";
        // Si el elemento que recorre es un type text y esta vacio
        if (formulario.elements[i].type == "text" && formulario.elements[i].value == "") {
            //Asigna la clase error a dicho elemento type text
            formulario.elements[i].className = "error";
            // Añadimos a la cadena el mensaje de error
            mensaje += "ERROR: " + formulario.elements[i].name + " no puede estar vacío.<br>";
            error = false; // pasamos error a false para que al devolverlo la funcion nos indique no ha ha validado ok.
            // sino, comprueba los type text que estan rellenos
            // Si el elemento que recorre es un type text y no esta vacio   
        } else if (formulario.elements[i].type == "text" && formulario.elements[i].value != "") {
            //Asigna la clase acierto a dicho elemento type text
            formulario.elements[i].className = "acierto";
            // No asignamos datos a la variable mensaje hasta que no valide cada requisito
        }
    }

    // Si todos los type text contenian texto no ha cambiado error a false con lo cual devolvería true (valida ok),
    // en caso contrario, al detectar cualquier campo type text vacío devuelve el error a false(no valida)
    return error;
}

//----------------------------------------------------------//

// Función que valida que el nombre cumpla el patrón requerido.
// Si lo cumple renombra la clase a acierto, añade datos a mensaje y devuelve true
// En caso contrario añade errores a mensaje, renombra la clase a error y devuelve false.
function validarnombre() {

    // Letras de la A a la Z mayusculas y minúsculas, espacios, vocales con tilde en mayusculas y minusculas, 
    //    letra ñ y ç en mayusculas y minusculas. Entre 3 y 40 veces
    var patron = /^[a-zA-ZñÑçÇáéíóúÁÉÍÓÚ\s]{3,40}$/;
    // Si cumple el patrón
    if (patron.test(document.getElementById("nombre").value)) {
        // renombra la clase como acierto
        document.getElementById("nombre").className = "acierto";
        // Añadimos a la cadena el mensaje de acierto con los datos introducidos
        mensaje += document.getElementById("nombre").name + " : " + document.getElementById("nombre").value + ". <br>";
        return true;
    } else {
        // Añadimos a la cadena el mensaje de error al no validar el patrón
        mensaje += "NOMBRE ERRONEO: debe tener caracteres alfabéticos y espacios (entre 3 y 40 caracteres).";

        // Asignamos la clase error.
        document.getElementById("nombre").className = "error";

        return false;
    }
}

//----------------------------------------------------------//

// Función que valida que la contraseña cumpla el patrón requerido y que ambas contraseñas sean iguales. 
function validarapellidos() {

    // Letras de la A a la Z mayusculas y minúsculas, espacios, vocales con tilde en mayusculas y minusculas, 
    // letra ñ y ç en mayusculas y minusculas. entre 4 y 60 veces
    var patron = /^[a-zA-ZñÑçÇáéíóúÁÉÍÓÚ\s]{4,60}$/;
    // Si cumple el patrón
    if (patron.test(document.getElementById("apellidos").value)) {
        // renombra la clase como acierto
        document.getElementById("apellidos").className = "acierto";
        // Añadimos a la cadena el mensaje de acierto con los datos introducidos
        mensaje += document.getElementById("apellidos").name + " : " + document.getElementById("apellidos").value + ". <br>";
        return true;
    } else {
        // Añadimos a la cadena el mensaje de error si no cumple el patrón.
        mensaje += "APELLIDOS ERRONEOS: debe tener caracteres alfabéticos y espacios (entre 4 y 60 caracteres).";
        // Asignamos la clase error.
        document.getElementById("apellidos").className = "error";
        return false;
    }

}

//----------------------------------------------------------//

// Función que valida que la contraseña inicial cumpla el patrón requerido 
// y que coincidan las 2 contraseñas. 
function validarcontraseña() {
    //Entre 9 y 12 caracteres
    // Almenos 3 caracteres alfabéticos
    // Una minúscula mínimo y debe tener una ú
    // De 0 a 3 dígitos y que acabe en . } o # 
    var patron = /^(?=.*[a-zA-ZñÑçÇáéíóúÁÉÍÓÚ].*[a-zA-ZñÑçÇáéíóúÁÉÍÓÚ].*[a-zA-ZñÑçÇáéíóúÁÉÍÓÚ])(?=.*[a-zçñáéíóú]+)(?=.*ú{1})(?=(?:\D*\d){0,3}\D+$)(?=.*[\.|}|#]$)(?=^.{9,12}$)/;
    // Si no coincide con el patrón
    if (!patron.test(document.getElementById("contraseña").value)) {
        // añadimos a mensaje el mensaje de error
        mensaje += "CONTRASEÑA ERRONEA: Debe tener 1 minúscula y 3 caracteres alfabéticos almenos,de 0 a 3 dígitos una ú, acabar en . } o #  y tener entre 9 y 12 caracteres.";
        // Asignamos la clase error.
        document.getElementById("contraseña").className = "error";
        return false;

        // Si no coinciden ambas contraseñas
    } else if (document.getElementById("contraseña").value != document.getElementById("confirmar contraseña").value) {
        // añadimos a mensaje el mensaje de error
        mensaje += "ERROR: Las contraseñas no coinciden.";
        // Asignamos la clase error.
        document.getElementById("confirmar contraseña").className = "error";
        return false;

        // Si cumplen los patrones y ambas son iguales        
    } else {
        // Si la contraseña es correcta y coinciden ambas, le asignamos la clase acierto
        document.getElementById("contraseña").className = "acierto";
        document.getElementById("confirmar contraseña").className = "acierto";
        //Añadimos al mensaje el contenido de la contraseña
        mensaje += document.getElementById("contraseña").name + " : " + document.getElementById("contraseña").value + ". <br>"
        return true;
    }
}

//----------------------------------------------------------//

// Función que valida que se haya seleccionado alguna nación.
// Hemos decidido que si el valor del índice es 0 o no tiene valor(porque se haya eliminado con el boton limpiar campo)
// lanzaremos un error y no validará la nación, por iniciativa propia.
// En caso de querer que se inscriba la persona incluso si no hay ninguna nacionalidad elegida o el campo vacío
// bastaría con eliminar desde la línea 219 hasta la 228(ambas incluidas) y el paréntesis de la linea 237.

function validarnacion() {
    // Comprueba que la opción seleccionada sea diferente a 0.

    var error = true;
    // Si es 0 o no ha seleccionado ningún nombre de nación.
    if (document.getElementById("nacionalidad").selectedIndex == 0 || document.getElementById("nacionalidad").value == "") {
        // Añadimos mensaje de error
        mensaje += "ERROR: No ha seleccionado ninguna nacion. <br>";
        // Asignamos la clase error.
        document.getElementById("nacionalidad").className = "error";
        // si ha llegado hasta aqui, error pasa a false porque no valida la nacion
        error = false;
        // Si el indice seleccionado es distinto a 0
    } else {
        // Asignamos a la variable objNacionalidad el objeto nacionalidad
        var objNacionalidad = document.getElementById("nacionalidad");
        // Asignamos a valor el texto del indice seleccionado
        var valor = objNacionalidad.options[objNacionalidad.selectedIndex].text;
        // Asignamos la clase acierto
        document.getElementById("nacionalidad").className = "acierto";
        // Añadimos a mensaje la nacionalidad seleccionada
        mensaje += "Nacionalidad : " + valor;
    }

    return error;
}

//----------------------------------------------------------//

// Función que asigna a la variable elementoconfoco el id del type text o con id nacionalidad donde se ha hecho click
function guardarfoco() {

    if (document.activeElement.type == "text" || document.activeElement.id == "nacionalidad") {
        elementoconfoco = document.activeElement.id
    }
}

//----------------------------------------------------------//

//Función que limpia el valor del elemento que tiene el id de la variable elementofoco
function limpiarcampo() {

    document.getElementById(elementoconfoco).value = "";
}

//----------------------------------------------------------//


// Función que crea o borra la cookie,
// Recibe los parámetros de nombre de la cookie, valor y dias de expiración
function crearCookie(nombre, valor, dias) {
    // Si se indican los días de expiración
    if (dias) {
        // Se crea la variable date que almacenará la fecha actual
        var date = new Date();
        // Se añaden los días recibidos por parámetros
        date.setTime(date.getTime() + (dias * 24 * 60 * 60 * 1000));
        // creamos la variable expirar con el valor "; expires=" mas la variable date que contiene la fecha actual mas los dias añadidos
        var expirar = "; expires=" + date.toGMTString();

        // Si por parámetros no se pasa los días, la variable expirar quedará vacía, dando lugar luego a boorar la cookie al cerrar el navegador
    } else {
        // si no se le pasan días querrá decir que queremos borrarla cuando se cierre el navegador.
        var expirar = "";
    }
    // Creamos la cookie 
    document.cookie = nombre + "=" + valor + expirar + "; path=/";
}

//----------------------------------------------------------//

// Función que lee una cookie cuyo nombre se pasa por parámetro
function leerCookie(nombre) {
    // Creamos la variable micookie y almacenamos una cadena con el nombre pasado por parámetro y el signo =
    var nombrecookie = nombre + "=";
    // Creamos la variable cadena de tipo array, los valores de dicho array serán los pares de valores de la cookie del documento, 
    // cortando cada par donde encuentra un ; 
    var cadena = document.cookie.split(';');
    // Recorremos el array
    for (var i = 0; i < cadena.length; i++) {
        // guardamos en la variable c cada valor del array 
        var c = cadena[i];
        // Quitamos los espacios en blanco iniciales
        while (c.charAt(0) == ' ') c = c.substring(1, c.length);
        // Recorremos el array para buscar si encuentra nombrecookie, si se encuentra devolvemos el valor que le sigue
        if (c.indexOf(nombrecookie) == 0)
            return c.substring(nombrecookie.length, c.length);
    }
    // Si llega aquí es que no existe la cookie y devuelve el valor 0
    return 0;
}

//----------------------------------------------------------//

// Función que crea una cookie con valor de días negativo, con lo cual la anula/elimina
function borrarCookie(nombre) {
    crearCookie(nombre, "", -1);
}
