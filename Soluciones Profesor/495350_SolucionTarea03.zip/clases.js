/* 
   DWEC: Tarea3. Centuria Romana 2018-2019
   Autor: José Manuel Martín
*/

/* 
  Clase Infante
*/
class Infante {
   // Constructor de la clase Infante.
   constructor(nombre,edad,altura) {
       this._nombre=nombre;
       this._edad=edad;
       this._altura=altura;
   }

   // getter de nombre
   get nombre() {
       return this._nombre;
   }

   // setter de nombre
   set nombre(nuevoNombre) {
       this._nombre=nuevoNombre;
   }

   // getter de edad
   get edad() {
       return this._edad;
   }

   // setter de edad
   set edad(nuevaEdad) {
       if (nuevaEdad>0) this._edad=nuevaEdad;
       else _edad=0;
   }   

   // getter de altura
   get altura() {
       return this._altura;
   }

   // setter de altura
   set altura(nuevaAltura) {
       if (nuevaAltura>0) this._altura=nuevaAltura;
       else this._altura=0;
   }

   /*
     Método jubilar: Si el Infante tiene 45 años o más se Jubila.
        devuelve:
            true si se jubila
            false si no se jubila 
    */
   jubilar() {
       var sejubila;
       sejubila=false;
       if (this.edad>=45) {
          sejubila=true;
       }
       return (sejubila);
   }

   /* Método que retorna el valor de los atributos */
   toString() {
       let descjubilar="";
       if (this.jubilar()) descjubilar=" *** JUBILADO";       
       return(this.nombre+" "+this.edad+" años, "+this.altura+" centímetros."+descjubilar);
   }
}

/*
  Clase Centurion
*/
class Centurion extends Infante {

    // Constructor de la clase Centurion.
    constructor(nombre, edad, altura, tiempo) {
        super(nombre,edad,altura);
        this._tiempo=tiempo;                
    }

    // getter de tiempo
    get tiempo() {
        return this._tiempo;
    }

    // setter de tiempo
    set tiempo(nuevoTiempo) {
        this._tiempo=nuevoTiempo;
    }

    /*
      Función que grita una orden aleatoria de un array de órdenes en latín recibida.
      recibe: Array de órdenes en Latín.
      devuelve: Una cadena con la órden elegida aleatoriamente.
    */
    gritarOrden(ordenes) {
        let descOrden="";

        // Comprobamos que las órdenes vengan dadas a través de un array.
        if (Array.isArray(ordenes)) {
            // Seleccionamos aleatoriamente una orden del array de órdenes facilitadas.
            descOrden = ordenes[parseInt(Math.random()*ordenes.length)];            
        }

        return descOrden;
    }

    /* método que retorna el valor de los atributos y atributos de la clase heredada */
    toString() {        
        return "Centurion " + this.nombre+" "+this.edad+" años, "+this.altura+" centímetros." + " y "+this.tiempo+" años en el cargo";
    }
}


/*
  Clase Centuria
*/
class Centuria {

    // Constructor de la clase Centuria.
    constructor(nombre,legion,provincia) {
        this._nombre = nombre;
        this._legion = legion;
        this._provincia = provincia;
        this.arrayInfantes = new Array();
        this._centurion = null;
    }

    // getter de nombre
    get nombre() {
       return this._nombre;
    }

    // setter de nombre
    set nombre(nuevoNombre) {
        this._nombre=nuevoNombre;
    }

    // getter de legion
    get legion() {
        return this._legion;
    }

    // setter de legion
    set legion(nuevaLegion) {
        this._legion=nuevaLegion;
    }

    // getter de provincia
    get provincia() {
        return this._provincia;
    }

    // setter de provincia
    set provincia(nuevaProvincia) {
        this._provincia=nuevaProvincia;
    }

    /*
      Funcion que añade un Infante al Array de infantes. Se controla que no haya más de 77 infantes por centuria.
      recibe: Un objeto tipo clase Infante.            
    */
    addInfante(nuevoInfante) {
        /* Controlamos que no se puedan añadir más de 77 infantes.
           1. Si la centuria NO TIENE asignado todavía un centurión, el número de miembros en total son 77
           2. Si la centuria TIENE asignado un centurión, el número de Miembros en total son 78
           */
        if (((this.totalMiembros()<=78) && (this._centurion!=null)) || ((this.totalMiembros()<=77) && (this._centurion==null))) {        
          this.arrayInfantes.push(nuevoInfante);
        }
    }

    /*
      Función que añade un Centurión a la Centuria. El centurión que recibimos sustituye el ya existente.
      recibe: Un objeto tipo clase Centurion.
    */
    asignarCenturion(centurion) {
        this._centurion = centurion;
    }

    /*
      Función que elimina un Infante de la Centuria. Se controla que no haya menos de 10 infantes, en tal caso no se podría seguir eliminando.
      recibe: El nombre del infante a quitar.
      devuelve: true, en caso de haberse encontrado
                false, en caso de no encontrarse el infante, o de haber 10 infantes y por ende no poderse eliminar.
    */
    removeInfante(nombreInfante) {
        // Buscamos el nombre del infante y devolvemos si existe o no.
        var buclex=0;
        var encontrado=false;
        
        // Si la centuria tiene 10 infantes, ya no se pueden eliminar más.
        if (((this.totalMiembros()>11) && (this._centurion!=null)) || ((this.totalMiembros()>10) && (this._centurion==null))) {
            while((buclex < this.arrayInfantes.length) && (!encontrado)) {
                if (this.arrayInfantes[buclex].nombre==nombreInfante)
                    encontrado=true;
                else
                    buclex++;
            }
        }
        // Si existe eliminamos la posicion.
        if (encontrado) this.arrayInfantes.splice(buclex,1);

        return encontrado;
    }

    /*
      Función que devuelve el número de miembros que forman la centuria, incluido el centurión en caso de existir.
    */
    totalMiembros() {
        let miembros = this.arrayInfantes.length;

        // Si tiene asignada la Centuria un Centurión, se cuenta como un miembro más.
        if (this._centurion!=null) miembros++;

        return miembros;
    }

    // método que retorna el valor de los atributos de la centuria, se ha creado un mini-formato de presentación.
    toString() {
        let descripcion;

        // Devolvemos los datos con un mini-formateo de una tabla con una celda. Algo muy simple. 
        descripcion = "<table border='1'>";
        descripcion += "<tr><td>";

        // Montamos la descripción del nombre de la centuria.
        descripcion += "<h2>"+this._nombre+" / legión: "+this._legion+" / provincia "+this._provincia+"</h2>";

        // Montamos el nombre del centurión si hay de la centuria. En caso contrario se informa de que esta centuria no tiene asignado todavía centurión.
        descripcion+="<h3>";
        if (this._centurion!=null) descripcion += this._centurion;
        else descripcion += "Esta centuria no tiene asignado actualmente ningún centurión";
        descripcion+="</h3>";

        // Montamos la lista de infantes que forman esta centuria.
        for (var i in this.arrayInfantes)
          descripcion += "Infante - "+ this.arrayInfantes[i] +"<br/>";
        
        // Por último, montamos una línea con el total de unidades que forman la centuria.
        descripcion += "<br/>";
        descripcion += "<h3>centuria formada por "+this.totalMiembros()+" efectivos</h3>";

        descripcion += "</td></tr>";
        descripcion +='</table>';

        // Devolvemos los datos de la centuria.
        return descripcion;
    }

}
